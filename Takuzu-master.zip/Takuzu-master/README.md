# Takuzu
Projet de S1 DUT informatique.

Partie 1 faite: 1 probleme a regler

Partie 2 en cours.
