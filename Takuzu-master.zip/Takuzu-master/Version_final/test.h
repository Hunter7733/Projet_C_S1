//Partie 1

void test_creer_grille();
void test_est_indice_valide();
void test_est_cellule();
void test_get_val_cellule();
void test_set_val_cellule();
void test_est_cellule_initiale();
void test_est_cellule_vide();
void test_afficher_grille();


//Partie  2

void test_rendre_cellule_initiale();
void test_initialise_grille();
void test_est_grille_pleine();
void test_pas_un_zero_consecutifs();
void test_meme_nombre_zero_un();
void test_ligne_colonnes_distincts();
void test_est_partie_gagnee();
